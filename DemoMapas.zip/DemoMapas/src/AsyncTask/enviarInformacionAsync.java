package AsyncTask;

import android.os.AsyncTask;

public class enviarInformacionAsync extends AsyncTask<Void, Void, Void>{


	@Override
	protected Void doInBackground(Void... params) {
		// TODO Auto-generated method stub
		return null;
	}

}
